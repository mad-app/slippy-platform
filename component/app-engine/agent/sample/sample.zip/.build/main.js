"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const request_1 = __importDefault(require("request"));
const URL = "http://localhost:5400/testing"; //target
function main() {
    const postData = {
        'hello': 'world'
    };
    const postOption = {
        url: URL,
        json: postData
    };
    request_1.default.post(postOption, (err, res, body) => {
        if (!err && res.statusCode == 200) {
            console.log('test success');
            process.exit(0);
        }
        else {
            console.log("can't connect");
            // console.log(err);
            process.exit(1);
        }
    });
}
main();
//# sourceMappingURL=main.js.map